package INF2120.API;

/**
 * Contient les différentes constantes utilisées par le logiciel.
 */
public class Constantes {
    /**
     * Le nombre minimal de syllabe que l'utilisateur doit entrer pour la réduction.
     */
    public static final int MIN_NOMBRE_SYLLABE = 1;

}
